#ifndef MEAN_ABSOLUTE_ERROR_H
#define MEAN_ABSOLUTE_ERROR_H

#include <stdio.h>
#include <math.h>
#include "libpnm.h"

float mean_absolute_error(char *file_name_1_ptr, char *file_name_2_ptr);

#endif // MEAN_ABSOLUTE_ERROR_H
