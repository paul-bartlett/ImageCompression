#ifndef LZ77_DECODING_FUNCTION_H
#define LZ77_DECODING_FUNCTION_H

#include <stdio.h>
#include <string.h>
#include "libpnm.h"

void Decode_Using_LZ77(char *in_compressed_filename_Ptr);

#endif // LZ77_DECODING_FUNCTION_H
