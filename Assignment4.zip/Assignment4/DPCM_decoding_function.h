#ifndef DPCM_DECODING_FUNCTION_H
#define DPCM_DECODING_FUNCTION_H

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "libpnm.h"

void Decode_Using_DPCM (char *in_filename_Ptr);

#endif // DPCM_DECODING_FUNCTION_H
